from PIL import Image, ImageDraw, ImageFont
import time
import os

def show_splash_screen(logo_path, display_time=3):
    # Load the logo image from the provided path
    try:
        logo = Image.open(logo_path)
    except IOError:
        print(f"Logo '{logo_path}' not found.")
        return
    
    # Create an image for the splash screen
    splash_image = Image.new('RGBA', logo.size, (255, 255, 255, 255))
    draw = ImageDraw.Draw(splash_image)
    
    # Draw the logo onto the splash screen
    splash_image.paste(logo, (0, 0))
    
    # Add the text below the logo
    font = ImageFont.truetype("arial.ttf", 20)
    text = "IwGx Marmalade Font Builder by cronium Inc."
    text_bbox = draw.textbbox((0, 0), text, font=font)
    text_width = text_bbox[2] - text_bbox[0]
    text_height = text_bbox[3] - text_bbox[1]
    text_position = ((splash_image.width - text_width) // 2, splash_image.height - text_height - 10)
    draw.text(text_position, text, font=font, fill=(0, 0, 0, 255))  # black text
    
    # Display the splash screen image
    splash_image.show()

    # Wait for the specified time before closing the splash screen
    time.sleep(display_time)

def generate_tga_and_gx(text, font_path, charmap, font_size=40):
    # Load the font
    try:
        font = ImageFont.truetype(font_path, font_size)
    except IOError:
        print(f"Font '{font_path}' not found.")
        return
    
    # Calculate the text size and image size
    draw = ImageDraw.Draw(Image.new('RGBA', (1, 1)))
    text_bbox = draw.textbbox((0, 0), text, font=font)
    text_width = text_bbox[2] - text_bbox[0]
    text_height = text_bbox[3] - text_bbox[1]
    image_size = (text_width + 20, text_height + 20)  # Adding some padding

    # Create an image with a transparent background
    image = Image.new('RGBA', image_size, (255, 255, 255, 0))
    draw = ImageDraw.Draw(image)
    
    # Draw the text on the image
    position = (10, 10)  # Start drawing with a little padding
    draw.text(position, text, font=font, fill=(0, 0, 0, 255))  # black text
    
    # Save the image as a TGA file
    tga_filename = 'font.tga'
    image.save(tga_filename, format='TGA')
    
    # Create the .gx file
    gx_filename = 'font.gxfont'
    
    with open(gx_filename, 'w') as gx_file:
        gx_file.write("CIwGxFont\n{\n")
        gx_file.write("\tutf8 1\n")
        gx_file.write(f"\timage {tga_filename}\n")
        gx_file.write(f'\tcharmap "{charmap}"\n')
        gx_file.write("}\n")
    
    print(f"Generated {tga_filename} and {gx_filename} :3")

# Main program
logo_path = 'splash.png'  # Specify the path to your logo image
if not os.path.exists(logo_path):
    print(f"Logo image '{logo_path}' not found. Please place it in the same directory as this script.")
else:
    show_splash_screen(logo_path)

text_input = input("Enter the text you want to generate in the TGA file: ")
font_path = input("Enter the path to your font file (e.g., 'arial.ttf'): ")
charmap = input("Enter the character map (charmap) you want to include in the .gxfont file: ")
font_size = int(input("Enter the font size (default is 40): ") or "40")

generate_tga_and_gx(text_input, font_path, charmap, font_size)
